var events = require('events');
var application = require('http').createServer(handlerServer);
var url = require('url');

application.listen(8098);
var CRUD = require('./lib/animal-crud');

function handlerServer(request, response) {
  
  var parsedURL = url.parse(request.url, true);
  var path = parsedURL.pathname;
  var argv = parsedURL.query;
  
  switch(path) {
	  
	  case "/create":  
		  var names = ["Joya", "Merlin", "Yuri", "Gato", "Zarwich", "Thor", "Odín", "Sisko", "Kira", "Worf"];
		  var races = ["Común", "Siamés", "Alsaciano", "Angora", "Egipcio", "Nordico", "Africano", "Asiático", "Bajorano", "Klingon"];		  
		  for(var i = 0; i < 100; i++) {
			var randName = names[Math.floor(Math.random()*9)];
			var randRace = races[Math.floor(Math.random()*9)];			
			var dataAnimal = {"name" : randName, "race" : randRace};  	
			var testAnimal = new CRUD.Animal(dataAnimal);
			testAnimal.create();
		  }
	  break;
	  
	  case "/read":
		  var testAnimal = new CRUD.Animal();
		  testAnimal.read();
	  break;
	  
	  case "/delete":
		  var testAnimal = new CRUD.Animal();
		  var filterDel = {};
		  if(argv instanceof Object) {
			  filterDel = argv;			  
		  }		  
		  testAnimal.delete(filterDel);		  
	  break;	  
	  
	  case "/update":
		  var testAnimal = new CRUD.Animal();
		  var dataQuery = {"name" : "Thor"};
		  var dataSet = {"$set" : {"name" : "Thor, the mighty"}};
		  testAnimal.update(dataQuery, dataSet);
	  break;
  }  
  
  
  // MANEJADORES DE EVENTOS
  
  CRUD.eventManager.on("MongooseTutorial:CRUD:Create:OK", function(data) {
	  response.end("DATOS CREADOS");
  });
  
  CRUD.eventManager.on("MongooseTutorial:CRUD:Create:Error", function(data) {
	  response.end("ERROR: " + JSON.stringify(data));	  
  });
  
  CRUD.eventManager.on("MongooseTutorial:CRUD:Read:OK", function(data) {	  
	  response.end(JSON.stringify(data));
  });
  
  CRUD.eventManager.on("MongooseTutorial:CRUD:Read:Error", function(data) {
	  response.end("ERROR: " + JSON.stringify(data));	  
  });
  
  CRUD.eventManager.on("MongooseTutorial:CRUD:Delete:OK", function(data) {	  
	  response.end("FILAS BORRADAS: " + data);
  });
  
  CRUD.eventManager.on("MongooseTutorial:CRUD:Delete:Error", function(data) {
	  response.end("ERROR: " + JSON.stringify(data));	  
  });
  
  CRUD.eventManager.on("MongooseTutorial:CRUD:Update:Error", function(data) {
	  response.end("ERROR: " + JSON.stringify(data));	  
  });
  
  CRUD.eventManager.on("MongooseTutorial:CRUD:Update:OK", function(data) {	  
	  response.end("ACTUALIZADO CORRECTAMENTE");
  });
       
}
