var chatMultiApp = require('http').createServer(handleMultiChat);
var url = require('url');
var io = require('socket.io').listen(chatMultiApp);

chatMultiApp.listen(8056);

function newMsg(data)
{
	if(data.type == 'PRIVATE')
	{
		// Mensaje privado solo para un usuario... Interesante como mandar eso por el socket si hay mas
		// de un usuario conectado...		
	}
	else
	{
		// Mensaje público que debe ser 'broadcasted' a todos los usuarios		
	}	
}

function handleMultiChat(request, response)
{
	
}

/**
 * Vamos a definir la estrcutura de datos que recibimos.
 * Recuerda: Debe estar autentificada o se puede 'fakear'
 * 
 * var dataStruct = {'type', : GENERAL | PRIVATE, 
 * 					 'operation' : NEW_MSG, DISCONNECT,
 * 					 'msg': MESSAGE_TEXT,
 * 					 'private' : 
 * 								  {'from' : USER_NAME,
 * 								   'to' : USER_NAME }
 * 					};
 * 
 **/

io.sockets.on('connection', function(socket) {
	
	socket.emit('authData', {"authCookie" : socket.id});
	
	console.log(socket.id);
	console.log(socket.sessionid);
	
	socket.on('msg', function(data) {
		newMsg(socket, data);		
	});
});
